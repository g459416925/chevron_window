---
name: ios-protocol-signature
description: iOS 签名/协议算法还原。定位加密/签名入口(CommonCrypto CCCrypt/CC_MD5/CCHmac、白盒常量表)→ frida RPC 把目标函数当算法 oracle 在线验证 → arm64 unicorn 离线补环境(iOS 版 unidbg 思路)→ keychain/NSUserDefaults 取密钥 → 字节级复现验证。含生命周期绑定签名→在线兜底止损。触发词：签名逆向、sign、加密参数、算法还原、CommonCrypto、CCCrypt、CCHmac、白盒、frida RPC、主动调用、unicorn、arm64 模拟、keychain、字节级验证。
---

# iOS Protocol Signature —— 签名/协议算法还原

## 角色定位

把 iOS App 请求里的加密/签名参数**还原成可离线生成**的算法。终产出：Python（或 Python + 少量在线兜底）脚本，能脱离 App 生成合法签名。

> 📌 **先套全局心法**（`.claude/memory/reverse-signature-principles.md` + `reverse-principles-v2.md`）：每个动态参数先归三类——① 客户端纯算 ② 设备指纹（一次性采或可伪造）③ 服务器下发透传。**别把 ③ 误当 ① 死磕。** 开工前定死「什么叫找到」；交付要有字段谱系，禁止把没找到的写成已还原。

## 开工检查（攻坚任务，缺一禁开工）

- [ ] 目标能力一句话（可验证，如「homefeed code=0」）
- [ ] 判官：服务端语义 / 与真机 oracle 逐字节 / 下游接口
- [ ] 样本在手：真实抓包 + input→output 对。没有 → 先采集（ios-recon/dynamic），**禁止空手逆向**
- [ ] 止损：时间 / 烧号红线（高频无效签名会软封整机）
- [ ] 字段先分类 ①②③，再开撕

## iOS 与 Android 的关键差异

| 维度 | Android | iOS（本仓库） |
|---|---|---|
| 纯算引擎 | Java + JNI .so | ObjC/Swift + CommonCrypto / 自带 .dylib |
| 离线模拟 | unidbg | **无 unidbg**；unicorn 跑 arm64 裸函数，或 frida RPC |
| 主动调用 oracle | frida RPC / unidbg | 真机 RPC **受限于魔改无 ObjC**：优先 hook 符号当 oracle，或静态还原后对拍 |
| 常见库 | BouncyCastle | CommonCrypto；部分 SDK 静态链接 OpenSSL 1.0.2（同盾） |

## 决策树

```
定位到签名/加密函数后:
   │
   ├─ 是标准算法(CCHmac/AES/MD5/SHA/RSA)?
   │     → hook 抓 key/iv/输入 → Python 复现 → 字节级校验
   │
   ├─ 是自定义纯算 / CFF-VM（无硬件墙）?
   │     → 抠函数 + unicorn；Interceptor 失败改 HWBP 抓态
   │     → 超大 OLLVM：Hex-Rays/d810 会 too big → FlowChart CFG，不是墙
   │
   ├─ 依赖设备指纹(②)?  → 一次性采 或 按纪律独立伪造（禁复用真机模板）
   │
   ├─ 依赖服务器下发值(③ token/nonce/salt/shield)?
   │     → 先打上游接口拿 → 喂给下游（注意时效）
   │
   └─ 「离线失败」其实是传输通道指纹?
         → 同盾：静态 OpenSSL + 私有 TLV 头，不是算法错。先复现通道
```

## ①②③ 实战对照（防再分错）

| 字段 | 归类 | 证据 | 反例（别再犯） |
|---|---|---|---|
| 快看 app_secret_sign | ① | MD5(gbs(dev)+gbs(盐)+双时间戳+params) 83/83 | — |
| 小红书 x-mini-sig 后半 / KDF | ① | preimage+KDF 已破 | first-half 仍 OPEN，勿标已还原 |
| 小红书 shield | ③ | 真空 50s 不获取；keychain 存服务器首装下发；缺→406 | 当本地算法撕 |
| 小红书 XYSS/token | ① | SETTOK 在首个网络前；base64(keychain 96B) | 旧实验 FUZZY bt 触发反检测 → 假「非本地」 |
| 小红书 d / mua | ① | AES-128-CBC(X25519(priv,PEER)[:16], …) | — |
| 懂车帝 Gorgon / Helios digest | ① | 真公式已锁 | Helios seed4 是 ② 随机合法，勿升级成 ① |
| 懂车帝 Medusa CT | **不声称①**（写路径 OPEN） | 帧结构①；unicorn 能跑 cipher，但旧「613/613=100%」是密钥调度缓冲不是密文；注入真 CT 仍 follow **4001**。见 `dongchedi-medusa-ct-vm` | 首页软校验 / 内容匹配 100% ≠ 写接口① |
| 山姆 st | ① | 纯离线 | — |
| 山姆 QIMEI / Turing v2 | ① 协议 | 注册/CMS 本地可造 | — |
| 山姆同盾 token | ①+通道 | box 可 forge；过闸还要通道指纹+星座 | profile `000` ≠ check 过闸 |
| 山姆 const_hex93 | 本质随机 | 启动 arc4random 48B | 当可还原常量撕 |
| 酷牛登录 | ① | RSA-1024 同公钥双加密 + UA md5 | — |
| 携程 XPS 首页 | ① 但软校验 | 空/错也 Success | 「e2e 过」≠ 算法对 |

## Step 1：定位签名入口

```
1. 抓包看哪个参数是签名（ios-recon Step 6 SSL hook）
2. 静态：IDA / strings / 类名 *sign* *hmac* *crypt*；注意 ida-pro-mcp 多实例漂移
3. 动态：纯原生 Interceptor 对拍输出 == 抓包值
   本机无 ObjC RPC 模板时，用 hook onLeave 当 oracle，不要写 ObjC.classes.SignManager
```

## Step 2：真机当 oracle（受 ObjC 限制）

```javascript
// 可行：hook 已定位的 C/导出符号，send 入参+出参
// 不可行：rpc.exports 里调 ObjC.classes.xxx（本机 ObjC 不存在）
rpc.exports = {
  ping: function() { return "pong"; }
};
```

能静态还原的不要长期挂真机 oracle（风控 + 设备绑定）。懂车帝 follow 写路径曾用设备 `getFeatureHash` 混合通，纯主机 CT 仍 OPEN——混合要在谱系里标明 oracle 依赖，禁止宣称纯协议。

## Step 3：unicorn 离线（CFF-VM / 白盒）

```
已验证的工程坑（懂车帝 CT replay；**不等于 CT 已升①**）：
- 代码页永远用文件（frida module.size 只到 __TEXT，别把 __DATA 当堆 overlay 覆盖代码）
- __DATA 必须是运行期已 rebase 的值，否则指针图全废
- 全对象图 BFS 会杀 App（~5200 页）→ 断点处只抓 per-request，其余 on-demand rpc readpage
- libSystem 要 shim（malloc/objc_msgSend 返 nil/锁 noop）；别 let-run 全部 objc
- 验证用「内容交集」不是地址；**高熵 100% 匹配可能是 P-无关密钥调度缓冲**（clock-diff 恒 100% = 假密文）
- 超大 OLLVM：d810 阉割/硬限制见 ios-recon 矩阵 + [[d810-ollvm-unflattening-recipe]]；不要在本节再抄激活步骤
- e2e 未过（懂车帝 follow 4001）前禁止把 VM replay 标成 ①
```

依赖系统库过多时性价比低 → 退回 hook oracle。VMP/重混淆 = **工期**，用户选定硬啃就推进到 VM 还原完，不半途改口「不可还原」。

## Step 4：取密钥 / 伪造纪律

```
- 运行时 key：CCCrypt/CCHmac hook
- keychain：能调用 SecItem*；hook SecItemAdd 可能被检测
- 硬编码盐/S盒：砸壳后 strings / IDA
- 指纹伪造：每台独立 env（机型↔芯片配对）；禁复用真机模板（聚类会连累真机）
- 测试禁用真机指纹（山姆）
- 共享 XXID / 共享 box 头 = 批量被聚类的病根
```

## Step 5：字节级复现 + 谱系交付

```python
for sample in samples:  # ≥3 组非样例
    assert my_offline_sign(sample.input) == sample.real
```

交付必须有**参数谱系表**（每字段一行：来源 / 算法 / 生命周期 / 单变量验证）。来源四选一：静态常量 / 本地生成 / 服务端下发 / 派生。硬编码抓包值必须标「重放+时效」。脚本内部若向真机取值 → 标明 oracle，禁止写「纯协议」。

**禁词牌照**（无证据不准结案）：
- 「被风控了」= 原版同环境也挂 +（维度轮换或冷却自愈）
- 「已还原」= 谱系零空洞 + ≥3 组任意输入对拍 + 动态字段单变量落定
- 「随机生成」= ≥3 样本同输入无规律（const_hex93 是正例）

## 止损线 & 风控红线

- **真止损** = 服务器强制硬件 attestation / SE 每请求现场签。普通请求签名极少。
- **通道指纹 ≠ 算法墙**：同盾离线失败根因可以是 ClientHello/前置头，不是 box 算错。
- **星座/双闸**：box 质量过了，commit 仍可能看 device-id+token 履历或集群记忆。换号/冷却，不要高频重试。
- **profile `000` 是「接受上报」不是「过闸」**。
- **e2e 绝不高频重试无效签名** → 软封整设备。单次 / 有效令牌 / 间隔久 / 先存 code=0 基线 / 连续失败立刻停。
- **白盒/CFF ≠ 止损**。const_hex93 这类**本质随机**才标不可还原（有牌照）。

## 已完成签名矩阵（摘要）

| App | 主体 | 状态 |
|---|---|---|
| 快看 | app_secret_sign | ① 完全还原 |
| 小红书 | x-mini / shield / d | 后半+KDF+d ①；shield ③；first-half OPEN |
| 懂车帝 | Gorgon+Helios+Medusa | 首页纯主机；**CT 不声称①**（e2e 4001）；写路径混合 |
| 山姆 | st + QIMEI + 同盾 + Turing | 三件套可本地；commit 另有星座/集群闸 |
| 携程 | XPS | 首页软校验 e2e |
| 酷牛 | 登录 RSA + 直播 URL | 登录/转播纯协议 |

## 交接

- 需要动态抓 key / 绕检测拿样本 → **ios-dynamic**。
- 需要砸壳静态定位 → **ios-unpack** → **ios-recon**。

## 常见坑（失败模式编码 S-xx）

> 每条格式：**编码 现象** → 原因/规则。**成本**=不知道这条会白费多少。
- **S-01 把 ③ 当算法硬撕** → 先分类。**成本**：数天到永远（shield）。
- **S-02 找 iOS 版 unidbg** → 没有。RPC/hook oracle + unicorn。**成本**：调研半天。
- **S-03 unicorn 跑到系统库就崩** → 依赖多则退 oracle；或按 CT 经验 shim。**成本**：补桩 1 天。
- **S-04 CCHmac 参数读错** → alg,key,keyLen,data,dataLen。**成本**：当算法错重撕。
- **S-05 算法对但签名不对** → 漏 ③ / 编码顺序；更危险的是高频 e2e 软封设备。**成本**：封号/封机。
- **S-06 反检测导致假「非本地」** → hook 把流程掐死（SETTOK=0）。先换安全 hook 再下结论。**成本**：整条 token 来源推倒重来。
- **S-07 复用真机指纹模板** → 聚类连累真机。每台独立 forge。**成本**：真号被限。
- **S-08 profile 000 当过闸** → 只是接受上报。**成本**：批量「成功」上线后全灭。
- **S-09 算法对、通道错** → 静态 OpenSSL/私有头/旧 ClientHello。先复现传输。**成本**：无限改 box。
- **S-10 单闸过了还有星座** → box ↔ device-id/token 双检；集群记忆冷却。**成本**：同一伪造配方刷到封。
- **S-11 软校验 e2e 当还原完成** → 首页放过 ≠ 写接口硬校验。按牌照升级 ①/②。
