---
name: ios-unpack
description: iOS 砸壳与脱壳。识别 FairPlay 加密(cryptid)→选砸壳方案→执行(手工 frida 内存 dump 优先/bfdecrypt 备选；frida-ios-dump·bagbak·dumpdecrypted 本机已弃用)→校验解密产物(cryptid=0)→产出可静态分析的 decrypted IPA/Mach-O。含 dyld_shared_cache 抽取系统库。触发词：砸壳、脱壳、解密、FairPlay、cryptid、frida-ios-dump、bagbak、bfdecrypt、dumpdecrypted、dump ipa、dyld cache 抽库。
---

# iOS Unpack —— 砸壳与脱壳

## 角色定位

把 **FairPlay 加密的 App Store 二进制**解密成明文，让 ios-recon / ios-protocol-signature 能静态分析。iOS 的"壳"不是第三方加固，而是 **Apple 官方 FairPlay DRM**——`__TEXT` 段（或其中一段）被加密，进程加载时由内核解密到内存。**砸壳 = 从内存 dump 出已解密的段回写文件**。

> ⚠️ **工具纪律**：阉割点/版本/弃用替代 **只查 ios-recon「工具阉割矩阵」**，本节不重复。本机 `tools/frida-ios-dump` 是 AloneMonkey **未补丁**原版 → **不要跑**。砸壳默认方案 A。

## 砸壳原理

```
App Store 二进制:  LC_ENCRYPTION_INFO(_64).cryptid = 1
                   [cryptoff, cryptoff+cryptsize] 被 FairPlay 加密
                   ⚠ cryptsize 可能远小于 __TEXT（酷牛=4096，只加密一小段）
                   ↓ 进程启动，内核把这段解密进内存
砸壳:  运行 App → 从内存读 [cryptoff, cryptsize] → 覆写文件对应偏移
       → cryptid 改成 0 → 明文 Mach-O
```

## 决策树（选砸壳方案）

```
目标加密(cryptid=1)?
   │
   ├─ 越狱机(本项目基线) ── 首选顺序:
   │     1. 手工 frida 内存 dump（纯原生，走 27045）→ 最可控，适配部分加密
   │     2. bfdecrypt（OTA 后可能没装：ios_apt_search/install）
   │     3. bfdecrypt 仍没有、又不能手工 dump 时 → 停，回矩阵找替代；**不要**启用未补丁的 frida-ios-dump/bagbak
   │
   └─ 非越狱机 ──
         本机实测：TrollStore 骗过 CoreTrust 也拿不到任意进程 task port
         → 只能重签目标进 get-task-allow 或塞 gadget；要无限制 dump = 完整越狱
```

## 方案 A：手工 frida 内存 dump（首选，已在酷牛验证）

走魔改 27045 + 纯原生 JS（无 ObjC）。读 Mach-O header 找 `LC_ENCRYPTION_INFO_64`（cmd=0x2C）的 cryptoff/cryptsize，`ptr.readByteArray(cryptsize)` 回传，主机覆写 + cryptid=0。

```python
# 骨架：connect.get_modded_device() → spawn → 等模块加载 → 读 base+cryptoff
# 参考 projects/kuniu/dump_kuniu.py（部分加密只 dump 4096B 那一段）
```

要点：
- **按 LC 里的 cryptoff/cryptsize dump，不要假设整段 __TEXT**。
- spawn 后 dyld 可能还没映射完，短暂等待或重试读 header。
- `Memory.readByteArray` 已移除，必须 `ptr.readByteArray(len)`。
- 主二进制砸完还要扫 `PlugIns/*.appex`、`Frameworks/*.framework`（各有自己的 cryptid）。懂车帝：主二进制+12 个 framework 已砸，3 个 appex 仍加密（可暂缓）。

## 方案 B：bfdecrypt（设备 tweak，OTA 后先确认）

```bash
# 先看还在不在
ios_apt_list("bfdecrypt")
# 没有：ios_apt_search("bfdecrypt") → ios_apt_install(...) → respring
plutil -p /var/mobile/Library/Preferences/com.level3tjg.bfdecrypt.plist
# 前台启动目标 → 默认 /var/mobile/Documents/<App>.ipa
ios_pull("/var/mobile/Documents/Target.ipa", "projects/<target>/ipa/Target.ipa")
```

## 方案 C / D（frida-ios-dump · bagbak · dumpdecrypted）— 本机弃用

见 ios-recon 矩阵：`tools/frida-ios-dump` 仍 USB+alpine+ObjC；bagbak/dumpdecrypted **仓库无可用产物**、已弃用。再 clone、对未补丁副本打补丁、或临时编 dylib 都算开环——**统一回方案 A 手工 dump**（`projects/kuniu/dump_kuniu.py`）。

## 校验解密产物（必做）

```bash
otool -l Target.decrypted | grep -A5 LC_ENCRYPTION_INFO   # cryptid 必须 = 0
# 无 Mac 用设备端 jtool2（可能要先 ios_apt_install）
jtool2 -d objc Target.decrypted | head
# 再看 strings 是否出现可读类名/URL，不是密文
```
cryptid 仍为 1 或类名乱码 → 失败。部分加密时：cryptid=0 但只解密了 4096B，其余本来就是明文，属正常。

## dyld_shared_cache 抽取

```bash
ls /System/Library/Caches/com.apple.dyld/    # 或 /var/db/dyld/
ipsw dyld extract dyld_shared_cache_arm64 /usr/lib/libcommonCrypto.dylib
```

## 交接给下游

- 解密二进制 → 回 **ios-recon** 提头 / **ios-protocol-signature** 定位算法。
- 要 hook 运行时（而非静态）→ **ios-dynamic**。

## 常见坑（失败模式编码 U-xx）

> 每条格式：**编码 现象** → 原因/规则。**成本**=不知道这条会白费多少。
- **U-01 去跑 tools/frida-ios-dump 或再 clone 一份** → 原版未补，矩阵已弃用。走方案 A。**成本**：卡在 USB/ObjC/alpine 数小时。
- **U-02 attach 目标失败** → 后台 App 被挂起。改 spawn。**成本**：25s×N + 误判工具坏。
- **U-03 dump 出来 cryptid 还是 1** → 偏移错或没覆写 cryptid。校验必做。**成本**：假解密二进制 IDA 全废（最坑）。
- **U-04 去装 bagbak** → 矩阵：不装。**成本**：折腾 node 半天。
- **U-05 只砸了主二进制，漏了 PlugIns/Frameworks** → 各自加密。**成本**：关键逻辑在 framework，反复回头补砸。
- **U-06 想用 dumpdecrypted（网上多为 armv7）** → 已弃用（见矩阵），别为它编 arm64。走方案 A。**成本**：注入不生效查半天。
- **U-07 OTA 后 bfdecrypt/jtool2 不存在** → `/var/jb` 已空。先 `ios_apt_list` 再装，别改脚本。**成本**：当砸壳方案失效。
- **U-08 整段 __TEXT dump 但 cryptsize 只有 4K** → 部分加密。按 LC 字段 dump。**成本**：传几百 MB、对不齐偏移。
- **U-09 用依赖 ObjC 的 dump 脚本打 27045** → 本机魔改无 ObjC。改纯原生读 header。**成本**：脚本 load 即报 ObjC is not defined。
