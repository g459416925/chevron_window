---
name: ios-skill-evolver
description: iOS 逆向技能自进化系统。基于达尔文棘轮机制，每次完成逆向任务后自动评估→改进→测试→保留或回滚。9维 iOS 逆向领域评分体系(工具有效性/砸壳矩阵/失败编码/决策树/工具阉割修复/静态定位/pinning绕过/Frida兼容矩阵/实测)。触发词：进化 iOS 技能、更新砸壳矩阵、记录失败模式、评估 iOS skill、优化技能、技能进化。
---

# iOS Skill Evolver —— iOS 逆向技能自进化系统

## 角色定位

你是 iOS 逆向技能的"训练师"。确保 4 个逆向 skill（**ios-recon / ios-unpack / ios-dynamic / ios-protocol-signature**，必要时含本元技能）+ **`.mcp.json` / `mcp/ios-device-mcp/server.py`** 随每个新项目持续进化，只保留有可衡量改进的修改。

记忆权威源是仓库 `.claude/memory/`。Claude/ZCode 用户目录只作增量来源（[[claude-zcode-memory-sync-procedure]]：md5 diff，只拷新增/更新，保留独有）。**项目记忆 ≥40 条即触发全量重审**（2026-08-18 已触发并完成 Round 3）。

**设计灵感**：达尔文.skill v2.0（棘轮机制 + 9维评分）+ 女娲知识蒸馏方法论。

```
每次逆向任务完成 → 基线评估(9维) → 差距分析(找最低维) → 针对性改进(一轮只改一维)
   → 独立验证(子agent重评) → 分涨了?保留 : 回滚
```

## 核心原则

| # | 原则 | 说明 |
|---|------|------|
| 01 | 单一可编辑资产 | 每次只改一个 SKILL.md，变量可控 |
| 02 | 双重评估 | 结构评分(静态) + 实测(跑一个真逆向任务) |
| 03 | 棘轮机制 | 分数只升不降，退步自动回滚(用 git revert，不用 reset --hard) |
| 04 | 独立评分 | 评分用独立子 agent(自评准确率低，必须外部验证) |
| 05 | 人在回路 | 每个 skill 优化完暂停，用户确认 |

## 9 维 iOS 逆向领域评估体系（100分制）

### 结构维度（60分）

| # | 维度 | 满分 | 评估标准 |
|---|------|------|----------|
| 1 | **工具路径有效性** | 10 | venv frida 17.15.3 / tidevice / jtool2 / ldid / SSH relay 路径存在且可执行（class-dump/dsdump 本机不依赖，见阉割矩阵）|
| 2 | **砸壳/App 策略矩阵覆盖度** | 15 | 每个目标 App 的 加密(cryptid)/砸壳方案/网络栈/SSL pinning/越狱检测/签名主体方案 6 列完整 |
| 3 | **失败模式编码完整性** | 15 | R/U/D/S 各失败模式每条有：描述+案例+规则+成本(浪费时间) |
| 4 | **决策树可执行性** | 10 | 每个决策树分支有明确进入条件和执行步骤 |
| 5 | **工具阉割点/修复时效性** | 10 | 每个外部工具标注常见阉割点+修复方式+对齐版本(frida-ios-dump/dsdump/objection 等) |

### 效果维度（40分）

| # | 维度 | 满分 | 评估标准 |
|---|------|------|----------|
| 6 | **静态定位准确度** | 10 | jtool2/IDA（class-dump/dsdump 仅独立 Mac）定位签名·加密入口的手法与实际 Mach-O 匹配 |
| 7 | **抓包/pinning 绕过成功率** | 10 | 按 App pinning 强度(NSURLSession/TrustKit/BoringSSL)推荐的绕过方案可实际使用 |
| 8 | **Frida spawn/attach & 版本兼容矩阵** | 10 | spawn 优先、frida 17 兼容(ObjC bridge)、设备/App 版本组合准确无过时信息 |
| 9 | **实测验证通过率** | 10 | 随机抽一个已完成 iOS 逆向项目，按 skill 重新执行能否成功 |

## 进化循环：5 个 Phase

### Phase 1：基线评估
```
触发: "评估 iOS skills" / 完成一个 App 逆向后 / 发现 skill 指导错误 / 工具版本升级后
执行: 1.启独立子agent 做9维评分  2.输出每维得分+总分+最低维  3.🔴CHECKPOINT暂停给用户确认改什么
```
### Phase 2：单维度优化
```
规则: 一轮只改一维；优先最低分维；单轮涨幅<1分自动早停
执行: 1.针对最低维生成1个具体改进  2.编辑SKILL.md git commit  3.启2个独立子agent重评
     4.新分>旧分→保留  5.新分≤旧分→git revert  6.🔴CHECKPOINT展示diff+分数变化等确认
```
### Phase 3：回归测试
```
1.随机抽2个已完成项目关键步骤 2.用改进后skill重跑 3.查是否回归 4.🛑回归→强制回滚
```
### Phase 4：跨 Skill 联动检查
```
1.查4个skill一致性(frida版本/设备基线/SSH路径/venv 统一，cross-ref有效)
2.查 ios-dynamic 失败模式在 ios-protocol-signature 有对应止损/策略
3.查 ios-unpack 的加密/网络栈是否有对应 signature 案例与 ios-dynamic 注入策略
```
### Phase 5：知识蒸馏归档
```
1.新失败模式编码进项目记忆  2.新App加入 ios-recon 策略矩阵  3.新签名案例加入 ios-protocol-signature
4.更新 MEMORY.md  5.记录到 EVOLUTION_LOG.md(前分/后分/决策)  6.输出进化摘要
7.Claude/ZCode 用户目录增量对齐（禁止全量覆盖、禁止当权威源）
```

### Phase 6：MCP 对齐（与 skill 同期）
```
ios-device / .mcp.json 必须反映当前设备事实：
- frida 只走 27045（自动 relay），禁 27042 / set-default
- ios_setup_auth = mobile + sudo（sshd 禁 root 密码）
- ios_info 查 systemagentd/coreservice，不要查已卸载的 frida-server
- ios_frida 默认 spawn；文档写明无 ObjC/require
- ios_ssh 失败诊断指向越狱/openssh，不是 MCP 坏
改完跑 tools/sync-claude-to-cursor.ps1
```

## 触发决策路由
```
"评估 iOS skills"                 → Phase1 → 9维评分 → 暂停确认
"优化 <ios-recon|ios-unpack|ios-dynamic|ios-protocol-signature>" → Phase1→2→3
"更新砸壳矩阵"/"添加新App"          → Phase2 直接编辑 → skip 基线
"记录失败模式"/"又踩坑了"           → Phase5 追加失败模式编码 + 更新记忆
"全量进化"                        → 循环 recon→unpack→dynamic→signature→MCP→联动→归档(从最弱先修)
"检索 Claude/ZCode 记忆"          → Phase5 增量同步 + 蒸馏进 skill/MCP（禁止把用户目录当权威源）
"回滚上次进化"                    → git log → 确认 → git revert
```

## 反例黑名单 8 条（达尔文标准）
1. 同一AI又改又评（必须独立子agent）  2. 用 git reset --hard 回滚（必须 git revert）
3. 为凑分堆冗余（涨幅<1分早停）  4. 跳过回归直接评分  5. 一轮改多维
6. 干跑比例>30%（方向错了）  7. 静默跳过异常  8. 忽视维度相关簇

## 评估报告模板
```markdown
## Skill: <name> — 第 N 轮进化评估
### 基线评分 (上一轮: XX)
| # | 维度 | 得分 | 评价 |
|---|------|------|------|
| 1 | 工具路径有效性 | X/10 | ... |
| ...9维... |
| **总分** | | **XX/100** | |
### 最低维度: <名> (X/10)
### 改进方案: <描述>
### 改进后: XX/100 (+X.X)
### 棘轮决策: [保留/回滚]
```

## 进化触发事件清单
- [ ] 完成一个新 App 的 iOS 逆向
- [ ] 发现新的检测机制(新反-Frida/新 pinning 库)
- [ ] 工具版本升级致旧策略失效(frida/iOS/objection)
- [ ] 用户反馈"按 skill 做失败了"
- [ ] 新逆向方法论(新工具/新论文)
- [x] 项目记忆达 40 条(2026-08-18 全量重审 → Round 3)
- [ ] Claude/ZCode 用户目录与仓库 memory 再次分叉（增量同步）
- [ ] MCP 行为与 skill 文档不一致（默认端口/spawn/认证）

## 进化历史
记录在 `.claude/skills/EVOLUTION_LOG.md`。每轮按 `skill | 前 | 后 | 决策` 追加。
