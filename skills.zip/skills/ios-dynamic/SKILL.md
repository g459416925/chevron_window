---
name: ios-dynamic
description: iOS 动态调试/Frida 对抗/SSL/越狱检测。纯原生 Frida Hook(Interceptor/Stalker/硬件断点)——本机魔改 agent 无 ObjC bridge，不能 ObjC swizzle、objection 不可用；spawn 优先 vs attach；SSL Pinning 绕过(优先 hook libboringssl 抓明文)；越狱检测绕过；反-Frida 检测与对抗(魔改 server/agent)；cycript/LLDB+debugserver 用到再 apt。触发词：Frida、Hook、动态调试、spawn、attach、ObjC、Swift hook、objection、cycript、LLDB、debugserver、SSL pinning、越狱检测、反调试、反 Frida、注入秒退。
---

# iOS Dynamic —— 动态调试 / Frida 对抗 / SSL / 越狱检测

## 角色定位

运行期把目标 App 撬开：hook 看/改行为、抓明文流量、对抗反-Frida / 越狱检测。本仓库的**唯一可用 frida**是魔改 `systemagentd:27045`（level2 server + 源码 backtracer agent）。

> ⚠️ **本机硬事实（2026-08-12/15 实测）**：魔改 agent 是 QuickJS-only，**无 ObjC bridge**——`ObjC.available` 恒 false，`frida-compile` + `frida-objc-bridge` 也救不了。裸 `create_script` 另外还没有 `require` / 全局 `Frida`。**本设备只走纯原生**：`Module.getGlobalExportByName` + `Interceptor.attach` / 硬件断点。见 [[modded-frida-no-objc-bridge]] [[frida17-bare-inject-no-objc-bridge]]。

## 连接（第一课，必记）

```
只连 27045：  tidevice relay 27045 27045
              d = frida.get_device_manager().add_remote_device('127.0.0.1:27045')
              或 connect.get_modded_device()（幂等起 relay）
              或 ios-device MCP 的 ios_frida（内部走 27045）

禁止：
  get_usb_device() / get_device(UDID)     → 打不存在的原版 27042，或选中同机安卓
  deploy_frida.py --set-default            → 曾内核 panic / 掉越狱
  默认 frida-mcp（USB）                    → 本机原版未装；日常注入用 ios_frida / Python
```

`tidevice list` 空但 USB 正常 → Windows **Apple Mobile Device Service** 自停；已有 relay 会变**僵尸**（本地 TCP 仍 accept，`add_remote_device` **无限 hang**）。先杀光 `*relay 27045*` 进程只留一个；`net start` AMDS 需管理员。见 [[windows-amds-flap-zombie-relay]]。

**AMDS 反复抖 / tidevice relay 老僵尸 → 改走 SSH 本地转发隧道**（SSH-over-usbmux 实测最稳，2026-08-18 酷牛回归验证）：

```
tidevice relay 2222 22                                              # SSH 传输层（一次）
icacls frida-mod\keys\id_ios /inheritance:r; icacls frida-mod\keys\id_ios /grant:r "$($env:USERNAME):R"   # win 私钥权限，否则 ssh 忽略
ssh -i frida-mod/keys/id_ios -p 2222 -N -L 27045:127.0.0.1:27045 root@127.0.0.1     # 隧道
# 之后 frida 连 127.0.0.1:27045 走隧道到设备（systemagentd 绑 127.0.0.1:27045）
```

设备端 frida 卡死（TCP 通但 frida 握手 hang，`launchctl list|grep coreload` 见上次退出 `-9`）→ `ssh … "launchctl kickstart -k system/re.coreload.svc"` 重拉。**(重)启后首次握手 ~10s**，连通探测 watchdog **必须 ≥15s**，否则把「慢」误判成「死」。

## spawn vs attach

```
iOS 挂起后台 App → attach = 固定 25s 超时（不是环境坏）
   → 一律 spawn:  pid = d.spawn([bundle_id]); s = d.attach(pid); load; d.resume(pid)
   → 必须 attach 运行中的: 先切前台
懂车帝 h2：attach 热进程会 HPACK desync 漏一半 → 必须冷启动 spawn 前装 hook
```

```python
from connect import get_modded_device
d = get_modded_device()
pid = d.spawn(["com.target.app"])
s = d.attach(pid)
sc = s.create_script(open("projects/<t>/hooks/hook.js", encoding="utf-8").read())
sc.on("message", lambda m, _: print(m.get("payload", m)))
sc.load()
d.resume(pid)
```

## frida 17 + 本机魔改 API 速查

**版本钉死**：主机 `.venv` frida **17.15.3**（全局 16.5.9 → ProtocolError）↔ 设备魔改 `systemagentd`(level2)@**27045**（原版 27042 未装，禁 `--set-default` 抢）。完整阉割点/替代只看 ios-recon 阉割矩阵，本表不再抄。

| 要做 | 正确写法 | 禁止 |
|---|---|---|
| 全局符号 | `Module.getGlobalExportByName("CCCrypt")` | `Module.getExportByName(null, …)`（17 不是函数） |
| 读内存 | `ptr.readByteArray(n)` / `ptr.readUtf8String()` | `Memory.readByteArray(ptr,n)`（已移除；空 catch → 抓 0 条） |
| hook C 函数 | `Interceptor.attach(addr, {onEnter,onLeave})` | `Interceptor.replace` ObjC IMP（XHS metasec abort） |
| 混淆/CFF 中段 | 硬件断点 `Thread.setHardwareBreakpoint` + `Process.setExceptionHandler` | 对 dispatcher 邻近指令 Interceptor（unable to intercept） |
| 抓栈 | HWBP + 手读 fp 链（`Backtracer.ACCURATE` 也不要依赖） | `Thread.backtrace(ctx, Backtracer.FUZZY)`（XHS **必崩**） |
| 枚举类 | IDA / 砸壳后静态；运行时勿 `objc_copyClassList` 全量 | `ObjC.classes`（本机不存在） |
| 版本 | 不要读 `Frida.version` | 全局 `Frida` 未定义 |

硬件断点模板见 [[ios-frida17-hwbp-api]]。每线程独立槽位；后建线程用 `attachThreadObserver`。exception handler 非本断点必须 `return false`。

## Step 1：定位入口（无 ObjC 枚举）

静态（砸壳 + IDA / `otool -Iv` / strings）定符号或 RVA，再：

```javascript
const m = Process.getModuleByName("Target"); // 或 enumerateModules 找
const addr = m.base.add(0xEA5AFBC);          // RVA
Interceptor.attach(addr, {
  onEnter(args) { send({t:"in", a0: args[0].toString()}); },
  onLeave(ret)  { send({t:"out", r: ret.toString()}); }
});
```

`frida-trace` 需自己连 27045，且本机无 ObjC `-m "*[*Sign*]"` 那套。优先 Python + 纯原生脚本。

## Step 2：抓加密（CommonCrypto / Security）

```javascript
function exp(name) {
  return Module.getGlobalExportByName(name);
}
Interceptor.attach(exp("CCCrypt"), {
  onEnter(a) {
    const klen = a[4].toInt32();
    send({t:"CCCrypt", op:a[0].toInt32(), alg:a[1].toInt32(),
          key: a[3].readByteArray(klen)});
  }
});
// CCHmac: alg,key,keyLen,data,dataLen
// SecItemCopyMatching / SecKeyEncrypt / SecKeyDecrypt
// 酷牛：无 bridge 时用 objc_msgSend 的 description 读返回值（见 kuniu login_trace.js）
```

XHS：hook `SecItemAdd` 会被检测；**调用** `SecItemDelete`/`SecItemAdd`（不 hook）安全。改 ObjC 行为用 attach IMP 改 arg/retval，禁用 replace。

## Step 3：抓包（本 skill 主路径，优于绕 pinning + 代理）

已在快看 / 懂车帝 / 携程 / 酷牛验证：

1. spawn 挂起态**先**装反检测（见 Step 5）再装 SSL hook，再 resume。
2. 同时 hook：`libboringssl.dylib` **和** App 内 `boringssl`/`openssl`/`libssl`/`cronet`。
3. 延迟补钩（`setInterval` 3s × 40）：spawn 时 dyld 未完，模块后出现。
4. `SSL_write` onEnter / `SSL_read` onLeave 用 `ptr.readByteArray`；`send(meta, ArrayBuffer)` 落盘。
5. 离线解 h2（HPACK）+ HTTP/1.1。模板：`projects/kuniu/hooks/ssl_capture.js` + `scripts/parse_flows.py`。
6. QUIC 另钩；XHS 阻断 UDP **不会**回落 TCP，要 hook `enableQuic` getter 返 NO。

抓 0 条先查：反检测掐网 → readByteArray API → 漏了系统 libboringssl → QUIC → attach 热进程。见 [[frida-capture-fail-suspect-antidetect]] [[ios-boringssl-h2-capture-method]]。

## Step 4：SSL Pinning 绕过（代理场景才需要）

```
仅当必须走 HTTP 代理时（多数目标用 Step 3 hook 明文，不必绕 pinning）：
 1. 纯原生 hook `SecTrustEvaluateWithError`（符号，不依赖 ObjC）
 2. 静态定位 TrustKit / AFNetworking / Alamofire 的 IMP 再 attach
 3. SSL Kill Switch 3（OTA 后可能未装 → `ios_apt_install`）
objection：**本机不可用**（见 ios-recon 阉割矩阵），不要当步骤 1。
```

## Step 5：反-Frida / 越狱检测（先 bypass 再采）

**抓包或签名采集失败：先查反检测，别当环境脆弱。**

检测面（懂车帝 metasec / 小红书 / 数美）：

| 类 | 特征 | 对抗 |
|---|---|---|
| 线程名 | gum-js-loop / gmain / frida / pool-spawner | 魔改已改名；仍要 hook `pthread_getname_np` 清洗残留 |
| 路径 | frida-server、/var/jb、Cydia… | hook stat/open/access |
| 反调试 | sysctl P_TRACED、ptrace | hook sysctl 清位 |
| 代码完整性 | Interceptor.replace、热补丁邻近 dispatcher | 改 attach / HWBP |
| 栈特征 | FUZZY backtrace | 禁止；改手读 fp |
| 枚举 | objc_copyClassList 全量 | 禁止 |
| 累计 | 高频 spawn 20+ | 单会话 <15，间隔久 |

spawn 挂起态先装 bypass 再 resume。level2 已过山姆同盾轻检测 + 懂车帝 metasec 冷启动（2026-08-06）。level2 **不够**时补运行时 bypass，不要先怀疑 relay。

越狱路径欺骗（纯原生 hook `stat`/`access`/`NSFileManager` 需先静态拿到 IMP）：

```
常见路径: /Applications/Cydia.app /usr/sbin/frida-server /bin/bash /etc/apt /var/jb
酷牛 stee_isJailbreak_1..7 + sysctl：level2 实测不拦 hook，仍建议清 P_TRACED
```

## Step 6：CFF / Medusa 类 VM（Interceptor 失败时）

懂车帝 `eabf0a0`：内联 hook 报 unable to intercept → **HWBP** 抓入口/离开全态；unicorn 离线 replay 必须：**代码页用文件，__DATA 用运行期已 rebase 快照**；全闭包 BFS 会杀 App（~5200 页）→ **on-demand 分页**。禁 hook VM dispatcher 热点。见 [[dongchedi-medusa-ct-vm]]。

## objection / cycript / LLDB

状态与替代只查 ios-recon 阉割矩阵。本节不列版本、不教安装 objection。日常：纯原生脚本 + `ios_frida`。cycript/debugserver 用到再 apt。

## 交接

- 抓到密钥/参数但要还原完整算法 → **ios-protocol-signature**。
- 要静态确认 hook 点 → IDA（串行 + 地标）。

## 常见坑（失败模式编码 D-xx）

> 每条格式：**编码 现象** → 原因/规则。**成本**=不知道这条会白费多少。
- **D-01 ObjC is not defined** → 本机魔改无 bridge，不是脚本写错。改纯原生。**成本**：frida-compile 半天仍 false。
- **D-02 attach 后台 25s 超时** → spawn / 切前台。**成本**：空等 + 误判环境。
- **D-03 hook Swift 找不到** → 无 @objc，走 exports / IDA 地址。**成本**：在 ObjC.classes 里空转（本机更是没有这个对象）。
- **D-04 SSL 绕了还抓不到** → 静态 BoringSSL / QUIC / 漏系统库。**成本**：把 pinning 方案重试一遍。
- **D-05 注入秒退 / 卡死没网** → 反 Frida。先 Step 5，别重装 frida。**成本**：1 天+。
- **D-06 去装/升 objection** → 矩阵已弃用（无 ObjC）。改纯脚本。**成本**：卡环境半天。
- **D-07 非越狱 TrollStore attach InvalidArgumentError** → 内核硬限制，重签 get-task-allow 或完整越狱。**成本**：重签 tipa 来回数小时（已踩）。
- **D-08 Memory.readByteArray 不是函数** → 改 `ptr.readByteArray`；catch 必须 send 错误。**成本**：计数狂涨却 0 条，误判完整性还原。
- **D-09 Thread.backtrace(FUZZY)** → XHS 必崩 / token 不生成。改 HWBP+fp 链。**成本**：整条 token 来源实验作废（曾推出「非本地生成」假结论）。
- **D-10 Interceptor.attach 混淆中段失败** → HWBP。禁 hook dispatcher 热点。**成本**：script destroyed / abort。
- **D-11 --set-default 抢 27042** → 内核 panic。魔改永远旁挂 27045。**成本**：掉越狱。
- **D-12 hook NSURLSession / 加载 objc-bridge** → XHS 网络静默。只 hook SSL。**成本**：以为没流量。
- **D-13 spawn 当时模块还没有** → 延迟补钩。**成本**：W/R=0 误判网络栈。
- **D-14 高频 spawn** → 注册风控 + 反 Frida 升级。单次/间隔久。**成本**：连真机合法请求也被限。
- **D-15 27045 TCP 通但 frida 握手永久 hang** → 设备端 systemagentd 卡死（`launchctl list|grep coreload` 上次退出 -9）。`launchctl kickstart -k system/re.coreload.svc` 重拉，别重装 host frida。**成本**：误当 host/relay 坏，反复重连数十分钟（本次实测）。
- **D-16 连通探测 watchdog 太短误判死** → (重)启后首次 `add_remote_device+enumerate` 约 10s。watchdog <15s 会在成功前一两秒超时。设 ≥15s。**成本**：把正常但慢的 server 判死，去瞎修（实测 11.8s 才出 procs）。
