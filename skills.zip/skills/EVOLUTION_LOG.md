# iOS 逆向技能进化日志（EVOLUTION_LOG）

> 由 `ios-skill-evolver` 维护。每轮进化按下表追加：前分 / 后分 / 决策（KEEP/ROLLBACK）+ 关键改动。

## 技能清单（工序分工）

| skill | 工序 | 移植自（Android 模板 APPCodeObjectdemo1）|
|---|---|---|
| ios-recon | 侦察/静态入口 | android-recon |
| ios-unpack | 砸壳/脱壳 | android-unpack |
| ios-dynamic | 动态/对抗/SSL/越狱检测 | android-dynamic |
| ios-protocol-signature | 签名/协议还原 | protocol-signature-reverser |
| ios-skill-evolver | 进化元技能 | reverse-skill-evolver |

## Round 0（2026-07-05 初始移植）

从 Android 逆向框架移植改造为 iOS 版：
- 保留"真机优先 / 无 UI 优先 / 4 工序分工 / MCP 闭环 / 进化棘轮"骨架。
- Android → iOS 全量替换：jadx/apktool→class-dump/dsdump/jtool2；DEX 脱壳→FairPlay 砸壳；Magisk/Zygisk→palera1n/ElleKit；unidbg→frida RPC + unicorn；ADB→tidevice/usbmux；SO→dylib/Mach-O。
- 融入设备实测结论：spawn 优先（后台 attach 25s 超时）、frida 17.15.3 venv 隔离、bfdecrypt 砸壳、工具阉割需自修。
- 9 维评分体系 iOS 化。

| skill | 前 | 后 | 决策 |
|---|:--:|:--:|:--:|
| ios-recon | — | 初始 | NEW |
| ios-unpack | — | 初始 | NEW |
| ios-dynamic | — | 初始 | NEW |
| ios-protocol-signature | — | 初始 | NEW |
| ios-skill-evolver | — | 初始 | NEW |

## Round 1（2026-07-11 首轮基线评分 + dim1 优化）

**基线评估**（Phase 1）：2 个独立子 agent 9 维评分 → A 68 / B 72 → **均值 70/100**。最低维 **#1 工具路径有效性（5.0/10）**。
两员共识硬伤：换机(8Plus→7Plus/rootful→rootless)后只改了设备基线表，正文命令示例仍用 `ssh mobile@127.0.0.1:alpine` + relay，私钥/ios-device MCP 列了却零调用；class-dump/dsdump 是 macOS 二进制、win32 主机无原生版却未交代运行位置。

**Phase 2 优化 dim1**（改前备份 `.pre-dim1`，无 git 用文件备份做棘轮）：
- ios-recon：SSH 段 `mobile:alpine` → root 免密钥(`ssh -i frida-mod/keys/id_ios root@…`)+ ios-device MCP(ios_ssh/push/pull) 列首选；class-dump/dsdump 加"macOS-only，win32 用设备端 jtool2 / frida ObjC runtime"三路说明。
- ios-unpack：bfdecrypt 拉取/frida-ios-dump/dumpdecrypted 三处命令 `mobile:alpine`→root+私钥/MCP；校验 class-dump→jtool2；U-06 A11→arm64(A7+)。

**独立复评**（2 个全新 agent）：C 76 / D 75 → **均值 75.5**。dim1 **5.0→9.0**。

| 轮次 | 前分 | 后分 | Δ | dim1 | 决策 |
|---|:--:|:--:|:--:|:--:|:--:|
| Round 1 (dim1) | 70.0 | **75.5** | **+5.5** | 5.0→9.0 | **KEEP**（远超 <1 早停阈值，无回归）|

> Phase 3 回归测试：暂无已完成真实项目可回归，跳过（待首个目标 App 逆向后补）。

## Round 2（2026-07-11 dim3 优化：失败模式补"成本"字段）

**Phase 2 优化 dim3**（改前备份 `.pre-dim3`）：给全部 **23 条失败码**（R×5/U×6/D×7/S×5）逐条补 **"成本"字段**（踩坑耗时/触发风控/封设备代价），含本会话真实踩坑数据：D-07"重签重装 tipa 来回 2 次全无效耗数小时"、S-05"高频重试无效签名→服务端软封整设备"、U-03"假解密二进制静态分析全废(看似成功最坑)"。

**独立复评**（2 个全新 agent E/F）：E 85 / F 80 → **均值 82.5**。dim3 **7.0→12.0**（E/F 均给 12,高度一致;成本字段 23/23 齐全)。

| 轮次 | 前分 | 后分 | Δ | 目标维 | 决策 |
|---|:--:|:--:|:--:|:--:|:--:|
| Round 1 (dim1) | 70.0 | 75.5 | +5.5 | 工具路径 5→9 | KEEP |
| Round 2 (dim3) | 75.5 | **82.5** | **+7.0** | 失败模式 7→12 | **KEEP** |

> dim3 未满 15：四要素"案例"常与"成本"合并(闭合~80%)、6 条成本用泛化"数小时"——**需真实逆向踩坑数据补足**,不宜编造(黑名单#3 凑分)。
> **下一轮候选**：最低维现为 **#9 实测验证（6.5/10）** —— 但 4 员一致指出:该维只能靠**真机实跑捕获真实输出/日志**改进,纯改文本无法提升(且违反"不凑分"原则)。**建议先跑通首个真实目标 App**,边实战边给 dim9(实测证据)+ dim3(真实成本案例)补真数据。

## Round 3（2026-08-18 全量知识蒸馏 + MCP 对齐）

**触发**：用户要求检索 Claude/ZCode 记忆并迭代 `.claude` 权威源；记忆已 >40 条（evolver 全量重审门槛）；Round 2 之后完成了快看/小红书/懂车帝/山姆/携程/酷牛实战，skill 仍停在 15.7.2 / 27042 / 「agent 自带 ObjC」。

**Phase 5 记忆增量**（md5 diff，不覆盖独有）：
- 仓库 `.claude/memory`：46 → 76 条量级（收 ZCode 独有 19 + Claude 新 6 + 若干更新）
- 用户目录不当权威；`MEMORY.md` 按设备/Frida/IDA/目标/山姆重编索引

**蒸馏进 4 skill（跨维，属归档轮不是单维凑分）**：
- 设备基线 → 15.8.8 / Dopamine 3.0.4 / **只连 27045** / OTA 清空 `/var/jb`
- 新失败码：R-06..11、U-07..09、D-08..14、S-06..11（均带真实案例+成本）
- ios-recon：App 策略矩阵 6 列；抓包改 SSL hook 优先；IDA 漂移；AMDS/僵尸 relay
- ios-unpack：手工纯原生 dump 升首选；部分加密 cryptsize=4096；bfdecrypt 可能未装
- ios-dynamic：魔改 **无 ObjC**；API 速查表；反检测先于环境；HWBP；禁 FUZZY bt / set-default
- ios-protocol-signature：①②③ 实战对照表；谱系/禁词牌照；通道指纹 vs 算法；星座双闸
- evolver：+Phase 6 MCP 对齐；记忆同步路由

**Phase 6 MCP**：`ios_setup_auth` 改 mobile+sudo；`ios_info` 查 systemagentd；`_frida_device` 自动 relay；`ios_frida` 默认 spawn + 无 ObjC 说明；`.mcp.json` 注释对齐 27045。

| 轮次 | 类型 | 决策 |
|---|---|---|
| Round 3 | 全量蒸馏 + MCP | **KEEP**（补真实踩坑，非凑分；待独立子 agent 复评 dim2/3/7/8/9） |

> Round 2 指出的 dim9 现已有多项目实战锚点（矩阵+失败码案例），但仍需独立子 agent 打分才入棘轮分数表。

## Round 3 独立复评（2026-08-18 Phase 1）

2 个全新子 agent：**G 83.5** / **H 73.0** → **均值 78.3/100**（分差 10.5，H 更狠）。对照 Round 2 均值 82.5：数字下降**不触发整轮回滚**——旧分建在过时基线（15.7.2/27042/ObjC 可用）上，新 rubric 把「无 ObjC」当正确、把过标①当错误，不可比。Round 3 蒸馏（27045 / 无 ObjC / 矩阵 / 新失败码）**KEEP**。

| # | 维度 | G | H | 均值 |
|---|---|:--:|:--:|:--:|
| 1 | 工具路径 | 9.0 | 8.0 | 8.5 |
| 2 | 策略矩阵 | 12.0 | 10.5 | 11.3 |
| 3 | 失败模式 | 12.5 | 11.5 | 12.0 |
| 4 | 决策树 | 8.5 | 7.5 | 8.0 |
| 5 | 阉割修复 | 7.5 | 7.5 | **7.5** |
| 6 | 静态定位 | 8.5 | 6.5 | **7.5** |
| 7 | 抓包 | 9.0 | 7.5 | 8.3 |
| 8 | Frida 兼容 | 9.0 | 7.5 | 8.3 |
| 9 | 实测（纸面） | 7.5 | 6.5 | **7.0** |
| **总分** | | **83.5** | **73.0** | **78.3** |

**Phase 4 联动**：四 skill + MCP 在 15.8.8 / 27045 / venv 17.15.3 / `id_ios` / `ios_setup_auth` 上一致。D-09/S-06（FUZZY 假非本地）、D-08/抓包 0 条、U-08/酷牛 4096、S-08/000 欺骗 有对应。缺口：ios-protocol-signature 正文未重复写 15.8.8；ios-dynamic YAML 仍写 ObjC swizzle。

**最低可改维**：#9 只能活体涨，不凑分。#5 与 #6 均值并列 7.5。H 坐实 **dim6 过标**：skill 把懂车帝 Medusa CT 写成 ① / 613/613，与 README「勿把 ② 写成 ①」+ memory「e2e 4001，不声称①」矛盾。相关簇=#9。**本轮 Phase 2 只改 dim6 分类**。

## Round 3.1（2026-08-18 Phase 2 dim6）

改前：对照表「CT = ①（VM）unicorn 613/613」；摘要「CT VM 离线 100%」；recon 矩阵「CT unicorn 100%」。
改后：一律 **不声称①**；写明旧 613/613 是密钥调度缓冲；follow e2e 4001；unicorn 节标成工程坑不是升①。recon 同行补 3 appex 仍加密（矩阵缺列，同簇）。

| 轮次 | 前分 | 后分 | 目标维 | 决策 |
|---|:--:|:--:|:--:|:--:|
| Round 3 蒸馏 | 82.5* | 78.3（新尺） | 全量归档 | **KEEP**（基线纠错；*旧尺不可比） |
| Round 3.1 dim6 | 78.3 | **81.3** | 静态定位过标 | **KEEP**（G2 81.5 / H2 81.0，分差 0.5；两员均确认不会再把 CT 标①） |

> dim6：H 6.5 → H2 7.5（+1.0）；G 估 8.5 档 → G2 8.0（分类修正后更严）。整包 +3.0 > 早停阈值 1。
> 下一轮候选：**#9 只能活体**（勿改文本凑分）；未封顶最低为 **#4 决策树 / #5 阉割修复（约 7.5–8.0）**。YAML 仍写 ObjC swizzle 属 #8 小缺口。

## Round 3.2（2026-08-18 Phase 2 dim5 阉割矩阵闭环）

复审（agent bcdd6484）挑出 dim5 4 处未闭环：dumpdecrypted 留「须自编 arm64」、unpack 方案 C/D「例外才自编」、recon 决策树/Step 4 仍并列 class-dump/dsdump 可跑命令、R-04 拿 dsdump 补 Swift（与矩阵「不下载」打架）。

改后：dumpdecrypted/frida-ios-dump/bagbak 一律 **弃用→手工 dump（`dump_kuniu.py`）**，删所有「临时编 dylib」；提头默认 **jtool2/IDA**，class-dump/dsdump 降为「仅独立 Mac 可跑、非本仓路径」诚实注脚；R-04/R-05 指向 IDA/`enumerateExports`；U-06 改「别为它编 arm64」；两处 YAML `description` 与 Step 3 用词同步（不再把弃用工具当主流程/默认动作，触发词保留）。

| 轮次 | 前分 | 后分 | 目标维 | 决策 |
|---|:--:|:--:|:--:|:--:|
| Round 3.2 dim5 | 7.5 | **9.0** | 阉割修复开环 | **KEEP**（复审确认 4 条全闭环、单真源成立、每条弃用都带已验证替代） |

> 复审复估 dim5 9/10。残留仅注脚级（已在本轮一并清）。单真源不变：整表只在 ios-recon，其余三 skill 回指。

## Round 3.3（2026-08-18 Phase 2 dim8 Frida 兼容矩阵）

最弱可改维排除 #9（只能活体、禁凑分）后落 **#8**：`ios-dynamic` YAML `description` 仍把「ObjC method swizzle / objection 无脚本操作 / cycript」当能力宣传，与正文硬事实「无 ObjC bridge」+ 阉割矩阵「objection 弃用」直接打架——命中 dim8「无过时信息」判据，且是会误导 agent 去试 ObjC swizzle 的元数据错误。

改后：能力句改成「纯原生 Interceptor/Stalker/硬件断点 + 明示无 ObjC bridge、objection 不可用」，**触发词全保留**（ObjC/objection/cycript 仍在，命中后由正文纠偏）。两员复评又一致点出同一封顶缺口→补「主机 17.15.3 ↔ 设备 level2@27045」版本钉死一行（只锚点、不抄矩阵，守单真源）+ 抓栈行补「ACCURATE 也不要依赖」消歧义。

| 轮次 | 前分 | 后分 | 目标维 | 决策 |
|---|:--:|:--:|:--:|:--:|
| Round 3.3 dim8 | 8.3 | **9.0** | Frida 元数据过时 | **KEEP**（评员 I/J 独立各 9/10；确认误导隐患消除、无矛盾、触发词完整） |

> 双评一致：唯一缺口=版本矩阵本体薄，已补锚点行。#9 仍只能活体。下一候选：**#4 决策树 / #6 静态定位（约 8.0）**。

## Round 3.4（2026-08-18 Phase 3 活体回归 · 通过；闭环 3 纸面盲点 + 5 环境坑）

用户选「跑真机活体回归」。抽 kuniu(net.kuniu) 按 skill 重跑。frida `.venv` 17.15.3 ✓。先暴露 3 处纸面 vs 现实缺口（均已闭环）：

1. **R-08 命中且修法不全**：`tidevice list` 空 → 实测 `Apple Mobile Device Service`=Stopped/Manual。按 skill `net start` **报「系统错误 5 拒绝访问」——需管理员**，skill 原文没写。→ 已改 R-08：补「查 Get-Service + 提权/管理员起 Cursor/重插/请用户启 + SSH-L 隧道兜底」，用户态只能杀旧 relay。
2. **kuniu 缺 README**（违反 CLAUDE 子项目强约束）：脚手架齐全（dump_kuniu.py / hooks/ssl_capture.js / scripts/parse_flows.py / analysis/*），却无 `README.md`。→ **已补** `projects/kuniu/README.md`（目标/现状/入口/风控红线）。
3. **旗舰模板与 dim8 速查表打架**：`ssl_capture.js:145` 读全局 `Frida.version`，而速查表明写「全局 Frida 未定义」。→ **已防御性收口**（`typeof Frida!=='undefined'?...:'n/a'`）；真机 `[ready] frida n/a` **定谳速查表正确、原模板会抛丢 ready 信号**。

**活体结果（提权后跑通全链）**：icacls 修 `id_ios` 权限 → SSH 通 → 确诊设备端 `re.coreload.svc` 卡死（TCP 通但 frida 握手 hang，上次退出 -9）→ `launchctl kickstart -k` 重拉 → **改走 SSH-L 隧道**（`ssh -N -L 27045`，绕开反复僵尸的 tidevice relay）→ `capture.py` spawn `net.kuniu` 纯原生抓包 **W37/R55、h2+h1、8 端点**（含数美 cc_info）→ `parse_flows.py` 离线还原 **26 flows（h2 HPACK 15 + h1 11）**，恢复 `app.kuniunet.com/mag/*` 业务 h2。**全程未碰登录**（e2e 纪律）。

关键定谳：`[ready] frida n/a` **实测证明魔改 agent 无全局 `Frida`**——dim8 速查表「Frida 未定义」判据正确，原模板 `ssl_capture.js:145` 会抛丢 ready 信号，防御性 `typeof Frida` 修复必要。

新编码失败模式：**D-15**（27045 TCP 通但握手 hang→kickstart 重拉，勿重装 host frida）、**D-16**（首握手~10s，watchdog≥15s，否则误判死；实测 11.8s 才出 procs=339）；R-08 补 SSH-L 隧道 + icacls；memory [[windows-amds-flap-zombie-relay]] 追加 SSH-L/kickstart/首握手/无全局 Frida 全套。

| 轮次 | 前分 | 后分 | 目标维 | 决策 |
|---|:--:|:--:|:--:|:--:|
| Round 3.4 dim9 | 7.0 | **8.0** | 活体回归 | **KEEP**（旗舰 harness 冷启动→抓包→离线还原全链真机跑通；暴露并闭环 5 个真环境坑，非纸面凑分） |

> #9 由 7.0→8.0：首次真机端到端验证过（连接/纯原生 hook/抓包/HPACK 还原）。未满分：仅验抓包链，签名 oracle/unicorn 复算未在本轮真机重跑。补 kuniu README（原缺，违反子项目强约束）。
