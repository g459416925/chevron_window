---
name: ios-recon
description: iOS 逆向侦察与静态分析总入口。连真机(tidevice/frida/SSH usbmux)、IPA 获取与 App 定位、Mach-O/FAT/dyld_shared_cache 结构解析、jtool2/IDA 提 ObjC/Swift 结构(class-dump/dsdump 本机不依赖)、符号/字符串/entitlements 提取、抓包治理、任务分诊。触发词：连真机、连设备、usbmux、拉 IPA、定位 App、Mach-O、dyld cache、class-dump、dsdump、提符号、entitlements、抓包、iOS 逆向入口。
---

# iOS Recon —— 侦察与静态分析（总入口）

## 角色定位

你是 iOS 逆向的**侦察兵和分诊台**。所有 iOS 逆向任务从这里进：连上真机、拿到目标二进制、判断加密与否、提取结构信息，然后**分诊**到 ios-unpack（要砸壳）/ ios-dynamic（要 hook）/ ios-protocol-signature（要还原算法）。

> ⚠️ **工具纪律**：外部工具默认当坏的。**阉割矩阵只在本节**（真源）；ios-unpack / ios-dynamic 禁止再抄一份补丁清单，只写执行步骤并回指本表。原则见 [[tools-often-crippled-need-repair]]。

## 工具阉割矩阵（dim5 真源，2026-08-18）

每行必须闭环：`本仓状态 → 阉割点 → 修法或弃用替代 → 归属`。修不了就**弃用并指向已验证替代**，禁止「再 git clone 一份网上原版」。

| 工具 | 本仓状态 | 阉割点（实测） | 闭环（修法 / 弃用替代） | 归属 |
|---|---|---|---|---|
| frida 主机 | `.venv` **17.15.3** | 全局 16.5.9 → ProtocolError | 只用 `.venv`；禁全局 | 全 skill |
| frida 设备 | `systemagentd@27045` + `coreservice.dylib`（自编译 level2+backtracer） | 网上 pre-modded / `build.rida.re` 特征不干净；源码 server SIGKILL | **只连 27045**；禁 `--set-default` 27042；原版未装 | ios-dynamic |
| `ios_frida` / 裸 `create_script` | MCP 默认 spawn、走 27045 | frida17 无全局 `ObjC`/`require`/`Frida`；本机魔改 **compile 也无 bridge** | 纯原生 `getGlobalExportByName`+`Interceptor`；`ptr.readByteArray` | ios-dynamic |
| frida-ios-dump | `tools/frida-ios-dump/` = **AloneMonkey 原版未补**（`get_usb_iphone`、`Password=alpine`、`dump.js` 用 `ObjC.classes`） | 打 27042；依赖 ObjC；SSH 密码 alpine | **弃用**。不要再 clone、不要在本副本上打补丁当可用。砸壳走 **手工 dump**（`projects/kuniu/dump_kuniu.py`） | ios-unpack |
| bagbak | **仓库无** | node/frida 版本墙，跟不上 17.15.3 + 无 ObjC | **不装**。同手工 dump | ios-unpack |
| dumpdecrypted | **仓库无 arm64 产物** | 网上常是 armv7；rootless 无 `/bin/sh` | **弃用**。砸壳走手工 dump（`projects/kuniu/dump_kuniu.py`）；不为它编 dylib | ios-unpack |
| bfdecrypt | OTA 后 **/var/jb 已空** | 当「设备已装」会空转 | `ios_apt_list` → 没有再 `ios_apt_install` → respring；仍优先手工 dump | ios-unpack |
| class-dump | **win32 仓库无二进制**（macOS-only） | 网上旧版不认新 Mach-O | **本机不装/不依赖**。提头：设备 `jtool2 -d objc`（先 apt）或 IDA。仅当另有独立 Mac 才可跑，非本仓基线 | ios-recon |
| dsdump | **仓库无** | 常见阉割=无 Swift metadata，输出不全却像成功 | **不下载/不依赖**。ObjC 头 → jtool2；Swift → IDA / `enumerateExports`（砸壳后静态；运行时无 ObjC.classes） | ios-recon |
| jtool2 | OTA 后可能未装（`/var/jb/usr/bin`） | 当「已 apt 装」会失败 | `ios_apt_list('jtool2')` → `ios_apt_install`；ldid 已装可先 `ldid -e` | ios-recon |
| objection | **本机不可用** | 要 frida 17 + **ObjC bridge**；老版 API 也不对 | **弃用**。SSL 走系统 `libboringssl` hook；越狱路径走纯原生 `stat`/`sysctl` | ios-dynamic |
| cycript / debugserver | OTA 清空 | 当已装会找不到 | 用到再 `ios_apt_install`；日常不依赖 | ios-dynamic |
| ida-pro-mcp | IDA 9.3sp1 portable；plugin **可能未装** | `select_instance` 不粘；并行 decompile 漂实例 | 先确认 plugin；串行 + `server_health` + 地标。路径见 [[ida-path]] | ios-recon |
| d810 | IDA 插件已有 recipes | 超大函数 Hex-Rays `too big` → hook 不触发 | 先显式 import optimizer；救不了就 FlowChart CFG。见 [[d810-ollvm-unflattening-recipe]] | ios-protocol-signature |
| frida-mcp | `.venv` 的 exe | USB 默认 **27042（未装）** | **日常不用**。注入走 `ios_frida` / `get_modded_device` | ios-dynamic |

**禁止开环**：为某个工具再去 GitHub 拉「最新阉割版」当修法。替代链路必须是本仓已验证脚本或 MCP/`ios_apt_*`。

## 设备基线（真机优先，2026-08-11 后）

| 项 | 值 |
|---|---|
| 机型/系统 | iPhone 7 Plus / **iOS 15.8.8** / arm64（A10 T8010，checkm8）|
| 越狱 | **Dopamine 3.0.4 rootless**（`/var/jb`）半不完美：重启后在 Dopamine App 内点 Jailbreak（不用电脑）|
| frida | **只连魔改**：`systemagentd@27045` + 源码 backtracer agent `coreservice.dylib`。原版 27042 **未装** |
| 连法 | `tidevice relay 27045 27045` + `frida.get_device_manager().add_remote_device('127.0.0.1:27045')`。**禁** `get_usb_device()` / `get_device(UDID)`（打到不存在的 27042；主机常同时挂安卓会选错）|
| SSH | **root 密钥免密**：私钥 `frida-mod/keys/id_ios`。sshd **禁 root 密码**。恢复：`ios_setup_auth`（mobile + sudo 推公钥），见 [[frida-root-shell-bypass]] |
| UDID | `f054f9edeb4dbea7978c24fe48f7b16f2be36f9f` |
| 设备端工具 | 已装：openssh / ldid / Sileo / level3 frida。**OTA 清空待装**：ellekit / bfdecrypt / Shadow / jtool2 / odcctools / debugserver / cycript → `ios_apt_install` |
| 首选连法 | **`ios-device` MCP**：`ios_ssh` / `ios_frida`(默认走 27045) / `ios_push`·`ios_pull` / `ios_apt_*` / `ios_setup_auth`。`frida-mcp` 走 USB 默认，本机基本不可用 |

**红线**：禁止 `deploy_frida.py --set-default` 抢 27042（曾内核 panic / 掉越狱）。设备改动只做加法+隔离。见 [[device-reboot-risk-jailbreak-loss]] [[modded-frida-deployed]]。

## 决策树（入口分诊）

```
连上设备（先 tidevice list；空则查 AMDS / 越狱）
   → 定位目标 App → otool -l 看 cryptid
   │
   ├─ cryptid=1（加密，App Store 几乎都是）
   │      → 转 ios-unpack 砸壳 → 拿 decrypted 二进制回来静态分析
   │
   ├─ cryptid=0（已解密 / 自签 / 砸过壳）
   │      → 设备 jtool2 提头 + IDA 静态定位（class-dump/dsdump 本机不依赖，见阉割矩阵）
   │
   ├─ 目标是"抓协议样本 / 看接口"
   │      → 首选 BoringSSL/h2 hook（见 Step 6），不要先配代理
   │
   └─ 目标是"还原某签名/加密参数"
          → 静态提头定位入口 → 转 ios-protocol-signature（配 ios-dynamic 动态验证）
```

## Step 1：连接设备（无 UI 优先）

```bash
# 项目 venv（勿用全局 frida）
cd e:/PythonCodeObject1/ios_reverser_opus
.venv/Scripts/tidevice list                    # 有 UDID 行 = usbmux 通
# 空但 USB 设备 Status=OK → Windows "Apple Mobile Device Service" 自停
#   sc query "Apple Mobile Device Service" → STOPPED 则 net start
#   旧 tidevice relay 会变僵尸：必须 taskkill 后再起。见 [[windows-amds-flap-zombie-relay]]

# frida：必须先 relay 27045，再 add_remote_device（connect.py get_modded_device 会幂等起 relay）
.venv/Scripts/python.exe connect.py --modded

# SSH：首选 ios-device MCP（usbmux 直连 22，免 relay）
#   ios_ssh("uname -a; ls /var/jb; sw_vers")
#   ios_ssh 失败 → 越狱未激活或 openssh 没了（OTA 清空），不是 MCP 坏
#     1) 设备上打开 Dopamine → Jailbreak
#     2) ios_apt_install('openssh')（若包没了）
#     3) ios_setup_auth(password=设备 mobile 密码) 推公钥
# 备用手动 SSH：
.venv/Scripts/tidevice relay 2222 22
ssh -i frida-mod/keys/id_ios root@127.0.0.1 -p 2222
```

OTA 清空 `/var/jb` 后补工具：`ios_apt_update` → `ios_apt_search` / `ios_apt_install`（走 `IOS_APT_PROXY`）。装 tweak 后 `ios_ssh("killall -9 SpringBoard")`。

frida 枚举（**只走 27045**）：
```python
import frida
# 或 from connect import get_modded_device; d = get_modded_device()
d = frida.get_device_manager().add_remote_device("127.0.0.1:27045")
for a in d.enumerate_applications():
    print(a.pid, a.identifier, a.name)
```

> 坑：`frida-ls-devices` / `frida` CLI 的 TUI 在 Git-Bash 里崩 → 用 Python API。`add_remote_device` 无限 hang 且不报错 = 僵尸 relay，先杀 relay 再查 AMDS。

## Step 2：定位目标 App 与容器

```bash
# 首选 ios_apps(filter="kuaikan") 或 SSH
find /var/containers/Bundle/Application -maxdepth 3 -name "*.app" 2>/dev/null
plutil -p "/path/Target.app/Info.plist" | grep -Ei "CFBundleIdentifier|CFBundleExecutable"
find /var/mobile/Containers/Data/Application -maxdepth 2 -name "*.plist" 2>/dev/null | head
```

## Step 3：判断加密（cryptid）

```bash
otool -l Target | grep -A5 LC_ENCRYPTION_INFO      # cryptid 1=加密 0=明文
# 注意 FairPlay「部分加密」：cryptsize 可能只有 4096（酷牛），不是整段 __TEXT
```
`cryptid=1` → 转 **ios-unpack**。别拿加密二进制去提头（jtool2/IDA 都只出密文垃圾）。

## Step 4：提取 ObjC/Swift 结构

本机基线 win32 无 Mac，**默认走设备 jtool2 + IDA**（class-dump/dsdump 不依赖，理由见阉割矩阵）：

```bash
# ObjC 头/方法（对 decrypted 二进制；设备端，OTA 后 jtool2 可能要先 ios_apt_install）
jtool2 -d objc Target
otool -Iv Target | head          # 导出/导入符号
otool -L Target                  # 依赖库
# Swift-only（无 @objc）：jtool2 看不到 → IDA，或 exports 兜底
strings -a Target | grep -E "^_\$s"     # Swift mangled 符号
# 运行时枚举类走不通：本机魔改 frida 无 ObjC bridge，别用 ios_frida 扫 ObjC.classes
```

> 只有另备**独立 Mac** 时才可跑 `class-dump -H` / `dsdump --objc --swift`（非本仓路径，且注意阉割版无 Swift）。
> 超大 OLLVM 函数：Hex-Rays / d810 会 `too big` → 走 IDA FlowChart CFG，见 [[d810-ollvm-unflattening-recipe]]。

## Step 5：entitlements / 签名信息 / IDA

```bash
ldid -e Target
otool -l Target | grep -A3 LC_CODE_SIGNATURE
```

**IDA（ida-pro-mcp）纪律**（[[ida-mcp-parallel-instance-drift]] [[ida-path]]）：
1. `list_instances` → `select_instance(port)` 后，**每次关键查询前**再看 `server_health` 的 `idb_path`，确认在目标二进制。
2. 用目标独有字符串做地标（如 discover 的 `x-mini-mua`、山姆的 `SCClassContentCell`）。
3. **禁止并行** `decompile` / `analyze_batch`（会漂回 active 实例，张冠李戴）。
4. 反编译里出现另一个 App 的符号 = 漂了，立刻停，别顺着假数据分析。

## Step 6：抓包治理（首选 hook，代理兜底）

```
优先级（越狱机已验证）：
 1. 纯原生 hook 系统 /usr/lib/libboringssl.dylib 的 SSL_read/SSL_write
    + 同时 hook App 模块名匹配 boringssl|openssl|libssl 的 SSL_*
    + 延迟补钩（spawn 后 dyld 未完，setInterval 数分钟）
    + 离线 HPACK 解 h2；HTTP/1.1 按 content-length/chunked 重组
    模板：projects/ctrip|kuniu|kuaikan 的 ssl_capture.js + parse_h2/parse_flows
 2. QUIC/TQUIC：另钩 TnetQuicRequest / 或 hook enableQuic 回落 TCP
    （XHS：阻断 UDP 不会回落，必须改 enableQuic）
 3. 代理 + CA + pinning 绕过：仅当 1 走不通（或要看非 TLS 明文）时
    iOS mitm 用 8889，勿抢安卓工程的 8888（projects/ios-capture）
```

抓不到包排查顺序：① 是否连了 27045 ② hook 是否空吞 `readByteArray` 异常 ③ 是否只钩了 App boringssl、漏了系统库 ④ 是否 QUIC ⑤ 是否反 Frida 把网络掐了（转 ios-dynamic）⑥ 是否 attach 热进程导致 HPACK desync（冷启动 spawn）。

## 已完成目标策略矩阵

| App | bundle | cryptid/砸壳 | 网络栈 | 检测 | 签名主体 | 抓包 |
|---|---|---|---|---|---|---|
| 快看 | com.kuaikan.comic | 已砸，无加固 | 业务系统 h2；广告 TQUIC | 弱 | app_secret_sign = MD5 双时间戳 ① | SSL hook |
| 小红书 | com.xingin.discover | 已砸 | boringssl + QUIC | metasec：禁 NSURLSession/FUZZY bt/replace | x-mini 四半段；shield=③；d=AES/X25519 ① | SSL + 禁 QUIC 属性 |
| 懂车帝 | com.ss.ios.auto | 主二进制已砸；3 appex 仍加密 | boringssl h2 | metasec/isecgm + Medusa CFF-VM | Gorgon/Helios ①；Medusa 帧①；**CT 不声称①** | **冷启动 spawn** |
| 山姆 | cn.samsclub.iphone | 已砸 | 业务系统 TLS；同盾=静态 OpenSSL1.0.2+TLV | 同盾通道指纹 | st ①；QIMEI/Turing/同盾三件套 | 通道≠系统 TLS |
| 携程 | ctrip.com | — | boringssl | 弱 | XPS（首页软校验） | SSL 四件套 |
| 酷牛 | net.kuniu | 部分加密 cryptsize=4096 | h2+h1 | 数美越狱检测（level2 不拦 hook） | 登录 RSA-1024 ① | SSL 四件套+延迟补钩 |

细则见 `.claude/memory/` 对应条。新目标按这 6 列补一行，再分诊。

## 交接给下游

| 现象 | 转交 |
|---|---|
| cryptid=1，要静态分析 | **ios-unpack** |
| 要 hook / 绕 SSL / 绕越狱检测 / 反 Frida | **ios-dynamic** |
| 要还原某签名/加密参数 | **ios-protocol-signature** |
| 二进制深度分析（arm64） | IDA + `ida-pro-mcp`（串行 + 地标） |

## 常见坑（失败模式编码 R-xx）

> 每条格式：**编码 现象** → 原因/规则。**成本**=不知道这条会白费多少。
- **R-01 拿全局 frida 连设备** → ProtocolError（16.5.9 vs 17.15.3）。永远用 `.venv`。**成本**：误当设备坏了去重装,~0.5 天。
- **R-02 attach 后台 App 超时 25s** → iOS 挂起后台进程。用 spawn，或先切前台。**成本**：每次干等 25s，多轮后误判环境坏。
- **R-03 对加密二进制提头** → 输出密文垃圾。先查 cryptid。**成本**：命名/画调用图全部作废。
- **R-04 jtool2 看不到 Swift 类** → 无 @objc，走 IDA / `enumerateExports`（**别下 dsdump**，矩阵已弃用）。**成本**：漏掉整条 Swift 业务。
- **R-05 想下 dsdump/class-dump 补 Swift** → 阉割版无 metadata。矩阵已弃用，改 jtool2/IDA。**成本**：以为提全了，后续全歪。
- **R-06 ios_ssh 失败当 MCP 坏** → 越狱未激活或 OTA 清空 openssh。先 Dopamine 重越 / `ios_apt_install`+`ios_setup_auth`。**成本**：重写 MCP、重启 Cursor，方向全错。
- **R-07 get_usb_device / 打 27042** → 本机原版未装；或选中同机安卓。只走 27045。**成本**：枚举空/连错设备，半天。
- **R-08 tidevice list 空 / add_remote hang** → AMDS 自停或僵尸 relay。查 `Get-Service 'Apple Mobile Device Service'`（常 Stopped/Manual，设 Automatic 仍会回停）+ 杀光 `*relay 27045*` 只留一个（用户态可做）。**`net start`/`Start-Service` 需管理员**（非提权报「系统错误 5」）→ 提权/管理员起 Cursor/重插/请用户启。AMDS 老抖就**改走 SSH-L 隧道**（`ssh -N -L 27045:127.0.0.1:27045`，win 私钥先 `icacls /inheritance:r /grant:r`），见 [[windows-amds-flap-zombie-relay]] + ios-dynamic 连接节。**成本**：误当 frida/数据线坏空转；非管理员干敲 net start 反复 access denied。
- **R-09 IDA 并行查询张冠李戴** → `select_instance` 不粘。串行 + server_health + 地标。**成本**：整轮分析建在别的 App 上（小红书会话实测）。
- **R-10 OTA 后仍按旧工具清单** → `/var/jb` 已空，bfdecrypt/jtool2/ElleKit 没了。先 `ios_apt_list` 再装。**成本**：砸壳/提头全失败却查脚本。
- **R-11 抓包先配代理** → pinning + QUIC 漏。先 SSL hook。**成本**：证书/代理/绕 pinning 大半天，其实 hook 半小时能出接口。
